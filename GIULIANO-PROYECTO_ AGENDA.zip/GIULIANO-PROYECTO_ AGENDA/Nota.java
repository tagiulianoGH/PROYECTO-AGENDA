
/**
 * Write a description of class Nota here.
 * 
 * @author Taiel Giuliano
 * @version 11/11/2024
 */
public class Nota
{
    private String titulo;
    private String texto;
    private int mes;
    private int dia;
    private Contactos contacto;

    /**
     * Crea una istancia de la clase nota, cargandola con sus respectivos datos
     */
    public Nota(String titulo, String texto, int mes, int dia, Contactos contactos){
        this.titulo = titulo;
        this.texto = texto;
        this.mes = mes;
        this.dia = dia;
        this.contacto = contactos;   
    }

    //Metodos geters y seters:
    //muestran las variables de clase y las modifican.

    
    public String getTitulo(){
        return this.titulo;
    }

    public void setTitulo(String titulo){
        this.titulo = titulo;
    }

    public String getTexto(){
        return this.texto;
    }

    public void setTexto(String texto){
        this.texto = texto;
    }
  
    public int getMes(){
        return this.mes;
    }

    public void setMes(int mes){
        this.mes = mes;
    }

    public int getDia(){
        return this.dia;
    }

    public void setDia(int dia){
        this.dia = dia;
    }

    public Contactos getContacto(){
        return this.contacto;
    }

    public void setContactos(Contactos contacto){
        this.contacto = contacto;
    }

}