import java.util.ArrayList;
import java.util.Collections;

/**
 * Una agenda que lleva un registro de notas.
 * 
 * @author Taiel Giuliano 
 * @version 11/11/2024
 */
public class Agenda
{
    private String nombre;
    private ArrayList<Nota> notas;

    /**
     * Crea una instancia de la clase Agenda. y carga su nombre.
     * @param String nombre de la agenda.
     */
    public Agenda(String nombre)
    {
       this.nombre = nombre;
       this.notas = new ArrayList<Nota>();
    }

    /**
     * Agrega una nueva notas a la lista
     * * @param notas nueva.
     */
    public void  agregarNota(Nota nota)
    {
        this.notas.add(nota);
    }
    
     /**
     * Mustra un listado de todos los datos de las notas de las agenda.
     */
    public void  listarNotas()
    {
        System.out.println("Agenda: " + getNombre() + ".");
        
        for (Nota nota : notas){
            System.out.println("Titulo: " + nota.getTitulo() + ". Texto: " + nota.getTexto() + ". Mes: " + nota.getMes() + ". Dia: " + nota.getDia() + ".");
            System.out.println("Contactos: " + nota.getContacto().getNombre() + ". Localidad: " + nota.getContacto().getLocalidad() + ". Direción: " + nota.getContacto().getDirección() + ".");
            System.out.println("Telfonos:");
            nota.getContacto().listarTelefonos();
            System.out.println("---------------------------------------------------------------------------------------------------");
        }
    }
    
    
    /**
     * Muestra un listado de todas las notas que tengan un conctacto en especifico.
     * @param String nombre del contacto deseado.
     */
    public void buscarXContacto(String nombre){
        int notasNum = 0;
        for (Nota nota : notas){
            if (nota.getContacto().getNombre().equals(nombre)){
                System.out.println("Titulo: " + nota.getTitulo() + ". Texto: " + nota.getTexto() + ". Mes: " + nota.getMes() + ". Dia: " + nota.getDia() + ".");
                System.out.println("Contactos: " + nota.getContacto().getNombre() + ". Localidad: " + nota.getContacto().getLocalidad() + ". Direción: " + nota.getContacto().getDirección() + ".");
                System.out.println("Telfonos:");
                nota.getContacto().listarTelefonos();
                System.out.println("---------------------------------------------------------------------------------------------------");
                notasNum++;
            }
        }
        if (notasNum == 0 ) System.out.println("El contacto:"+ nombre +". no se encuentra");
        else System.out.println("Total de notas: " + notasNum + ".");
    }
    
    
    /**
     * Muestra un listado de todas las notas que tengan un titulo en especifico.
     *  * @param String del titulo deseado.
     */
    public void buscarXTitulo(String titulo){
        int notasNum = 0;
        for (Nota nota : notas){
            if (nota.getTitulo().equals(titulo)) {
                System.out.println("Titulo: " + nota.getTitulo() + ". Texto: " + nota.getTexto() + ". Mes: " + nota.getMes() + ". Dia: " + nota.getDia() + ".");
                System.out.println("Contactos: " + nota.getContacto().getNombre() + ". Localidad: " + nota.getContacto().getLocalidad() + ". Direción: " + nota.getContacto().getDirección() + ".");
                System.out.println("Telfonos:");
                nota.getContacto().listarTelefonos();
                System.out.println("---------------------------------------------------------------------------------------------------");
                notasNum++;
            }
        }
        if (notasNum == 0 ) System.out.println("El titulo:"+ titulo +". no se encuentra");
        else System.out.println("Total de notas: " + notasNum + ".");
    }
    
    
     /**
     * Muestra un listado de todos los contactos de la lista en orden alfabetico.
     * 
     */
    public void listaContactosALfa() {
        ArrayList<String> nombres = new ArrayList<>();
    
        for (Nota nota : notas) {
            nombres.add(nota.getContacto().getNombre());
        }

        // Ordenar lista de nombres
        Collections.sort(nombres);
    
        // Imprimir la lista de contactos ordenada alfabéticamente
        for (String nombre : nombres) {
            System.out.println("Contacto: " + nombre);
        }
    }
    
    
    //Metodos geters y seters:
    //muestran las variables de clase y las modifican.

    
    public String getNombre(){
        return this.nombre;
    }

   
    public void setNombre(String nombre){
        this.nombre = nombre;
    }

    
    public java.util.ArrayList<Nota> getNotas(){
        return this.notas;
    }

 
    public void setNotas(java.util.ArrayList<Nota> notas){
        this.notas = notas;
    }

}//End class