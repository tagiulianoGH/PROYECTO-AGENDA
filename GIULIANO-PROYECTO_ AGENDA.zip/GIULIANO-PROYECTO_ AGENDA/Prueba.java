import java.util.*;
/**
 * Es una clase para testear las demas clases del proyecto.
 * 
 * @author Taiel Giuliano.
 * @version 11/11/2024.
 */
public class Prueba
{
    //Contactos de prueba:
    private Contactos  c1;
    private Contactos  c2;
    private Contactos  c3;
    private Contactos  c4;
    
    //Notas de Prueba
    private Nota  nota1;
    private Nota  nota2;
    private Nota  nota3;
    private Nota  nota4;
    
    //Agenda de Prueba:
    private Agenda agenda;
    
    /**
     * Crea instancias especificas de las clases Prueba, Contactos, Nota y Agenda.
     */
    public Prueba()
    {
        //Contactos de prueba:
        c1 = new Contactos("Juan_Puebla", "Santa_Fe", "25_de_Mayo_1111", "0341-111111");
        c2 = new Contactos("Pablo_Toledo", "Santa_Fe", "9_de_Julio_2231", "0341-112566");
        c3 = new Contactos("Martina_Rosales", "Helvecia", "Rivadavia_420", "03405-563777");
        c4 = new Contactos("Ana_Ropulo", "Helvecia", "bl.ocampo_1350", "03405-123456");
        
        //Notas de Prueba
        nota1 = new Nota("El Vago","No hay mucho que decir", 4, 8, c1);
        nota2 = new Nota("El Pobre", "Más seco que flor de plastico", 5, 6, c2);
        nota3 = new Nota("La Diva","-_(-_-)_-", 7, 10, c3);
        nota4 = new Nota("Ni idea","Apruebeme plis", 11, 13, c4);
        
        //Agenda de Prueba
        agenda = new Agenda( "Hola Mundo" );
    }

    
    /**
     * Agrega Telefonos de prueba a un contacto
     */
     public void ProbarTelefonos() {
         //Telefonos validos de prueba:
         System.out.println("Telefono valido de prueba 1: 0666-66666");
         System.out.println("Telefono valido de prueba 2: 0777-568842");
         System.out.println("");
         
         c1.agregarTelefono("0666","66666");
         c1.agregarTelefono("0777","568842");
         
         //prueba de los metodos de validación
         System.out.println("");
         System.out.println("Telefonos no validos");
         System.out.println("01234-12345678");
         System.out.println("0431a-568842");
         System.out.println("");
         
         c1.agregarTelefono("01234","12345678");
         c1.agregarTelefono("0431a","568842");
         
         //Telefonos validos de prueba:
         System.out.println("");
         System.out.println("Telefono valido de prueba 3: 0345-654321");
         System.out.println("Telefono valido de prueba 4: 0897-576459");
         System.out.println("");
         
         c1.agregarTelefono("0345","654321");
         c1.agregarTelefono("0897","576459");
         
         //Telefono extra para probar el metodo elementoVacio():
         System.out.println("");
         System.out.println("Telefono extra: 08650-5764321");
         System.out.println("");
         
         c1.agregarTelefono("08650","5764321");
         
         c1.listarTelefonos();
    }
    
    
    /**
     * Prueba el metodo agregarTelefono() de un contacto
     */
    public void agregarTelefonoPrueba() {
        c2.agregarTelefono();
    }
    
    
    /**
     * Agrega notas a la agenda.
     */
    public void agregarNotaPrueba() {
        agenda.agregarNota(nota1);
        agenda.agregarNota(nota2);
        agenda.agregarNota(nota3);
        agenda.agregarNota(nota4);
    }
    
    
    /**
     * Mustra un listado de todos los datos de las notas de la agenda.
     */
    public void listarNotasPruba(){
        agenda.listarNotas();
    }
    
    
    /**
     * prueba el metodo buscarXTitulo() de la clase Agenda
     *  * @param String del titulo deseado.
     */
    public void buscarXTituloPrueba(String titulo){
        agenda.buscarXTitulo(titulo);
    }
    
    
    /**
     * prueba el metodo buscarXContacto() de la clase Agenda
     *  * @param String del nombre del Contacto deseado.
     */
    public void buscarXContactoPrueba(String nombre){
        agenda.buscarXContacto(nombre);
    }
    
    
    public void listaContactosALfaPrueba(){
        agenda.listaContactosALfa();
    }
    
}
