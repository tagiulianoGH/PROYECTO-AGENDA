import java.util.*;

/**
 * Write a description of class Contactos here.
 * 
 * @author Taiel giuliano
 * @version 10/11/2024
 */
public class Contactos
{
    private String nombre;
    private String localidad;
    private String dirección;
    String[] telefono = new String[5];

    /**
     * Crea una instancia de la clase Contactos. y carga sus datos.
     * @param String nombre,localidad,dirección y telefono del contacto.
     */
    public Contactos(String nombre, String localidad, String dirección, String telefono)
    { 
      if (validarDato(nombre)) this.nombre = nombre.toUpperCase();
      else this.nombre = "S/D";
    
      if (validarDato(localidad )) this.localidad = localidad.toUpperCase() ;
      else this.localidad  = "S/D";
      
      if (validarDato(dirección)) this.dirección = dirección.toUpperCase();
      else this.dirección = "S/D";
      
      if (validarDato(telefono)) this.telefono[elementoVacio()] = telefono;
      else this.telefono[elementoVacio()] = null;
    
    }
    
    
    /**
     * Valida que el dato ingresado no sea nulo o vacio y que no tenga espacios en blanco.
     * 
     * @param  un dato tipo String.
     * @return  true si el dato no cumple con las condiciones y false si cumple alguna de ellas. 
     */
    private boolean validarDato(String dato)  {
        return dato != null && !dato.equals("") && dato.indexOf(" ") == -1;
    }
    /**
     * Imprime un listado de los telefonos.    
     */
    public void listarTelefonos() 
    {
        for (int i = 0; i < telefono.length; i++) {
            int aux = i + 1;
            System.out.println(aux + ") " + telefono[i]);
        }
    }
    
    /**
     * Valida que el telefono ingresado sea valido.
     * 
     * @param un telefono tipo String 
     * @return rue si el dato no cumple con las condiciones y false si cumple alguna de ellas. 
     */
    public boolean validarTelefono(String telefono) 
    {
        return validarDato(telefono) 
        && validarCaracteristica(telefono.substring(0,(telefono.indexOf("-")-1))) 
        && validarNúmero(telefono.substring((telefono.indexOf("-")+1) , telefono.length()));
        //&& validarNúmeroInt(Integer.parseInt(telefono.substring((telefono.indexOf("-")+1) , telefono.length())));
    }
    
    
    /**
     * Verifica si hay o no un espacio vacio en el arreglo.
     * 
     * @param
     * @return   El indice del elemento vacio del arreglo. o -1 si no lo hay
     */
    public int elementoVacio() {
        for (int i = 0; i < telefono.length; i++) {
            if ( (telefono[i] == null) || (telefono[i].equals("")) ) return i;
        }
        return -1;
    }
    
    
    /**
     * Verifica la caracteristica ingresada es validad.
     * 
     * @param una caracteristica tipo String.
     * @return un boolean true si la caracteristica es valida y un false si no lo es.
     */
    private boolean validarCaracteristica(String c){
        return c.matches("^[0-9]+$") && c.startsWith("0") && (c.length() >= 3) && (c.length() <= 5);
    }
    
    
    /**
     * Verifica el número ingresado sea validado.
     * 
     * @param un número de tipo int.
     * @return un boolean true si el número es valido y un false si no lo es.
     */
    private boolean validarNúmero(String num){
        return num.matches("^[0-9]+$") && !num.startsWith("0") && (num.length() >= 5) && (num.length() <= 7);
    }
    
    private boolean validarNúmeroInt(int n){
        String num = String.valueOf(n);
        return !num.startsWith("0") && (num.length() >= 5) && (num.length() <= 7); //&& num.matches("^[0-9]+$");
    }
    
    
    /**
     * Agrega un nuevo telefono al arreglo.
     */
    public void agregarTelefono() {
        Scanner sc = new Scanner (System.in);
        
        //validamos que halla espacio para un nuevo número
        int espacio = elementoVacio();
        if (espacio  == -1) System.out.println("No existe más lugar para agregar números telefónicos.");
        else {
            System.out.println("Ingrese  la caracteristica del telefono.");
            String carac = sc.nextLine();
            
            // Ingresamos y validamos la caracteristica:
            while (validarCaracteristica(carac) == false) {
                System.out.println("Error: la caracteristica no es valida.");
                System.out.println("Para que la caracteristica sea valida debe:");
                System.out.println("> Comensar con '0'.");
                System.out.println("> Tener entre 3 y 5 digitos.");       
                System.out.println("> Contener solo números.");
                System.out.println("Por favor ingrese de nuevo la caracteristica");
                carac = sc.nextLine();
            }
            
            // Ingresamos y validamos el número:
            System.out.println("Ingrese el número del telefono.");
            String num = sc.nextLine();
            while (!validarNúmero(num)) {
                System.out.println("Error: el número no es valido.");
                System.out.println("Para que el número sea valido debe cumplir las siguiente condiciones:");
                System.out.println("> No debe Comensar con '0'.");
                System.out.println("> Tener entre 5 y 7 digitos.");       
                System.out.println("> Debe contener solo números.");
                System.out.println("Por favor ingrese de nuevo el número");
                num = sc.nextLine();
            }
            
            //Guardamos el telfono en la lista:
            String mostrarNum = carac + "-" + num;
            System.out.println("Se ha agregado el nùmero: " + mostrarNum + " en el espacio " + espacio + ".");
            telefono[espacio] = mostrarNum;
        }
    }
    
    
    /**
     * Agrega un nuevo telefono al arreglo pidiendo los valores por parametro.
     * * @param caracteristica de tipo String y un número de tipo int.
     */
    public void agregarTelefono(String carac, String num) {
        int espacio = elementoVacio();
        if (espacio == -1) {
            System.out.println("No existen elementos vacíos.");
            return;
        }
        if (validarCaracteristica(carac) && validarNúmero(num)) {
            telefono[espacio] = carac + "-" + num;
        } else {
            System.out.println("El número ingresado es erróneo");
        }
    }
    
    
    /**
     * Elimina un telefono del arreglo.
     */
    public void eliminarTelefono() {
        //validamos que halla números en el vector
        int cont= 0;
         for (int i = 0; i < telefono.length; i++) {
            if ( (telefono[i] == null) || (telefono[i] == "") ) cont++;
        }
        
        
        if (cont == telefono.length) System.out.println("No existen números de teléfonos en la lista");
        else {
            //Listamos los telefonos:
            listarTelefonos();
            
            //Escaneamos el indice del telefono a eliminar:
            Scanner sc = new Scanner (System.in);
            System.out.println("Ingrese el indice del número del telefono que desea eliminar.");
            int eli = sc.nextInt();
            
            //Validamos que el indice sea valido:
            if (eli >=0 && eli <= 5) {
                //Eliminamos el telefono:
                this.telefono[eli] = "";
            } else System.out.println("Error: indice fuera de rango:");
        } 
    }
    
    
    /**
     * Modifica un telefono del arreglo.
     */
    public void modificarTelefono(){
        //validamos que halla números en el vector
        int cont= 0;
         for (int i = 0; i < telefono.length; i++) {
            if ( (telefono[i] == null) || (telefono[i] == "") ) cont++;
        }
        
        
        if (cont == telefono.length) System.out.println("No existen números de teléfonos en la lista para modificar");
        else {
            //listamos los telefonos:
            listarTelefonos();
            
            //Escaneamos el indice del telefono a eliminar:
            Scanner sc = new Scanner (System.in);
            System.out.println("Ingrese el indice del número del telefono que desea modificar.");
            int cambi = sc.nextInt();
            if (cambi >=0 && cambi <= 5) {
        
                System.out.println("Ingrese el nuevo número");
                String nuevo = sc.nextLine();
                if (validarTelefono(nuevo)){
                    //Actualizamos el telefono:
                    this.telefono[cambi] = nuevo;
                } else System.out.println("Error: número no valido:");
            } else System.out.println("Error: indice fuera de rango:");
        }
    }
    
    //Metodos geters y seters:
    //muestran las variables de clase y las modifican.

    
    public String getNombre(){
        return this.nombre;
    }

    
    public void setNombre(String nombre){
        this.nombre = nombre;
    }

    
    public String getLocalidad(){
        return this.localidad;
    }

    
    public void setLocalidad(String localidad){
        this.localidad = localidad;
    }

    
    public String getDirección(){
        return this.dirección;
    }

    
    public void setDirección(String direccin){
        this.dirección = dirección;
    }

    
    public String[] getTelefono(){
        return this.telefono;
    }
    
    public String getTelefono1(){
        return this.telefono[0];
    }
    
    public void setTelefono(String[] telefono){
        this.telefono = telefono;
    }

}//End class